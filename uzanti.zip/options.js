// Dil çevirileri
const translations = {
    'tr': {
        'optionsTitle': 'Google Sıra Numarası Ayarları',
        'domainsLabel': 'Vurgulanacak Alan Adları (Her satıra bir tane):',
        'fontSizeLabel': 'Yazı Boyutu:',
        'defaultColorLabel': 'Varsayılan Renk:',
        'highlightColorLabel': 'Vurgu Rengi:',
        'saveButton': 'Kaydet',
        'optionsSaved': 'Ayarlar kaydedildi!'
    },
    'en': {
        'optionsTitle': 'Google SERP Position Settings',
        'domainsLabel': 'Domains to highlight (one per line):',
        'fontSizeLabel': 'Font Size:',
        'defaultColorLabel': 'Default Color:',
        'highlightColorLabel': 'Highlight Color:',
        'saveButton': 'Save',
        'optionsSaved': 'Options saved!'
    },
    'de': {
        'optionsTitle': 'Google SERP Position Einstellungen',
        'domainsLabel': 'Zu markierende Domains (eine pro Zeile):',
        'fontSizeLabel': 'Schriftgröße:',
        'defaultColorLabel': 'Standardfarbe:',
        'highlightColorLabel': 'Hervorhebungsfarbe:',
        'saveButton': 'Speichern',
        'optionsSaved': 'Einstellungen gespeichert!'
    },
    'fr': {
        'optionsTitle': 'Paramètres de Position SERP Google',
        'domainsLabel': 'Domaines à surligner (un par ligne):',
        'fontSizeLabel': 'Taille de police:',
        'defaultColorLabel': 'Couleur par défaut:',
        'highlightColorLabel': 'Couleur de surbrillance:',
        'saveButton': 'Enregistrer',
        'optionsSaved': 'Options enregistrées!'
    },
    'es': {
        'optionsTitle': 'Configuración de Posición SERP de Google',
        'domainsLabel': 'Dominios para resaltar (uno por línea):',
        'fontSizeLabel': 'Tamaño de fuente:',
        'defaultColorLabel': 'Color predeterminado:',
        'highlightColorLabel': 'Color de resaltado:',
        'saveButton': 'Guardar',
        'optionsSaved': '¡Opciones guardadas!'
    }
};

// Belirli bir dil için çeviri al
function getTranslation(lang, key) {
    return translations[lang]?.[key] || translations['en'][key];
}

// Arayüzü çevir
function translateUI(lang) {
    document.querySelectorAll('[data-i18n]').forEach(element => {
        const key = element.getAttribute('data-i18n');
        element.textContent = getTranslation(lang, key);
    });
    document.title = getTranslation(lang, 'optionsTitle');
}

// Dil değiştirme fonksiyonu
function changeLanguage(lang) {
    chrome.storage.sync.set({ preferredLanguage: lang }, () => {
        translateUI(lang);
    });
}

// Ayarları chrome.storage'a kaydet
function saveOptions() {
    const domains = document.getElementById('domains').value
        .split('\n')
        .map(s => s.trim())
        .filter(Boolean);
    const fontSize = document.getElementById('fontSize').value;
    const defaultColor = document.getElementById('defaultColor').value;
    const highlightColor = document.getElementById('highlightColor').value;
  
    chrome.storage.sync.set({
        highlightDomains: domains,
        fontSize: fontSize,
        defaultColor: defaultColor,
        highlightColor: highlightColor
    }, function() {
        // Kullanıcıya bilgi ver
        const status = document.getElementById('status');
        chrome.storage.sync.get('preferredLanguage', function(data) {
            const currentLang = data.preferredLanguage || chrome.i18n.getUILanguage().split('-')[0];
            status.textContent = getTranslation(currentLang, 'optionsSaved');
        });
        setTimeout(function() {
            status.textContent = '';
        }, 750);
    });
}

// Kayıtlı ayarları yükle
function restoreOptions() {
    chrome.storage.sync.get({
        highlightDomains: [],
        fontSize: 35,
        defaultColor: '#838383',
        highlightColor: '#FF0000',
        preferredLanguage: chrome.i18n.getUILanguage().split('-')[0]
    }, function(items) {
        document.getElementById('domains').value = items.highlightDomains.join('\n');
        document.getElementById('fontSize').value = items.fontSize;
        document.getElementById('defaultColor').value = items.defaultColor;
        document.getElementById('highlightColor').value = items.highlightColor;
        document.getElementById('languageSelector').value = items.preferredLanguage;
        translateUI(items.preferredLanguage);
    });
}

// Sayfa yüklendiğinde çalışacak fonksiyonlar
document.addEventListener('DOMContentLoaded', function() {
    // Ayarları yükle
    restoreOptions();
    
    // Kaydet butonunu dinle
    document.getElementById('save').addEventListener('click', saveOptions);
    
    // Dil seçiciyi dinle
    document.getElementById('languageSelector').addEventListener('change', function() {
        changeLanguage(this.value);
    });
    
    // Font boyutu için input kontrolü
    const fontSizeInput = document.getElementById('fontSize');
    fontSizeInput.addEventListener('input', function() {
        const value = parseInt(this.value);
        if (value < 10) this.value = 10;
        if (value > 100) this.value = 100;
    });
});