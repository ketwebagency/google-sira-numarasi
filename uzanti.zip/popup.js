// Dil çevirilerini yükle
function loadI18nMessages() {
    const currentLang = document.documentElement.lang || 'tr';
    document.querySelectorAll('[data-i18n]').forEach(element => {
        const key = element.getAttribute('data-i18n');
        element.textContent = getTranslation(currentLang, key);
    });
}

// Dil değiştirme fonksiyonu
function changeLanguage(lang) {
    // HTML lang özelliğini güncelle
    document.documentElement.lang = lang;
    
    // Dil tercihini kaydet
    chrome.storage.sync.set({ preferredLanguage: lang }, () => {
        // Popup'ı güncelle
        updatePopupLanguage(lang);
        
        // Aktif sekmeyi bul ve mesaj gönder
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0] && tabs[0].url && tabs[0].url.includes('google.')) {
                try {
                    // Önce content script'i yükle
                    chrome.scripting.executeScript({
                        target: { tabId: tabs[0].id },
                        files: ['content.js']
                    }).then(() => {
                        // Sonra mesaj gönder
                        chrome.tabs.sendMessage(tabs[0].id, { 
                            action: "changeLanguage", 
                            lang: lang 
                        }).catch(err => console.log('Mesaj gönderme hatası:', err));
                    }).catch(err => console.log('Script yükleme hatası:', err));
                } catch (error) {
                    console.log('Tab işleme hatası:', error);
                }
            }
        });
    });
}

// Popup dilini güncelle
function updatePopupLanguage(lang) {
    try {
        // Başlık
        const titleElement = document.querySelector('h1[data-i18n="extensionName"]');
        if (titleElement) {
            titleElement.textContent = getTranslation(lang, 'extensionName');
        }
        
        // Açıklama
        const descElement = document.querySelector('div[data-i18n="extensionDescription"]');
        if (descElement) {
            descElement.textContent = getTranslation(lang, 'extensionDescription');
        }
        
        // Ayarlar butonu
        const optionsButton = document.querySelector('button[data-i18n="optionsLinkText"]');
        if (optionsButton) {
            optionsButton.textContent = getTranslation(lang, 'optionsLinkText');
        }
        
        // Göster/Gizle butonu
        const toggleButton = document.getElementById('toggleNumbers');
        if (toggleButton) {
            toggleButton.textContent = getTranslation(lang, 'toggleButtonText');
        }

        // Geliştirici bilgisi
        const developerElement = document.querySelector('span[data-i18n="developerText"]');
        if (developerElement) {
            developerElement.textContent = getTranslation(lang, 'developerText');
        }

        // Versiyon bilgisi
        const versionElement = document.querySelector('span[data-i18n="versionText"]');
        if (versionElement) {
            versionElement.textContent = getTranslation(lang, 'versionText');
        }

        // Sayfanın dilini güncelle
        document.documentElement.lang = lang;
    } catch (error) {
        console.log('Popup güncelleme hatası:', error);
    }
}

// Belirli bir dil için çeviri al
function getTranslation(lang, key) {
    const translations = {
        'tr': {
            'extensionName': 'Google Sıra Numarası',
            'extensionDescription': 'Google arama sonuçlarına otomatik sıra numarası ekler',
            'optionsLinkText': 'Ayarları Aç',
            'toggleButtonText': 'Numaraları Göster/Gizle',
            'developerText': 'Geliştirici: Nurullah ERDOĞAN',
            'versionText': 'Versiyon'
        },
        'en': {
            'extensionName': 'Google SERP Position',
            'extensionDescription': 'Adds position numbers to Google search results',
            'optionsLinkText': 'Open Settings',
            'toggleButtonText': 'Show/Hide Numbers',
            'developerText': 'Developer: Nurullah ERDOĞAN',
            'versionText': 'Version'
        },
        'de': {
            'extensionName': 'Google SERP Position',
            'extensionDescription': 'Fügt den Google-Suchergebnissen Positionsnummern hinzu',
            'optionsLinkText': 'Einstellungen öffnen',
            'toggleButtonText': 'Nummern ein-/ausblenden',
            'developerText': 'Entwickler: Nurullah ERDOĞAN',
            'versionText': 'Version'
        },
        'fr': {
            'extensionName': 'Position SERP Google',
            'extensionDescription': 'Ajoute des numéros de position aux résultats de recherche Google',
            'optionsLinkText': 'Ouvrir les paramètres',
            'toggleButtonText': 'Afficher/Masquer les numéros',
            'developerText': 'Développeur: Nurullah ERDOĞAN',
            'versionText': 'Version'
        },
        'es': {
            'extensionName': 'Posición SERP de Google',
            'extensionDescription': 'Añade números de posición a los resultados de búsqueda de Google',
            'optionsLinkText': 'Abrir ajustes',
            'toggleButtonText': 'Mostrar/Ocultar números',
            'developerText': 'Desarrollador: Nurullah ERDOĞAN',
            'versionText': 'Versión'
        }
    };
    
    try {
        return translations[lang][key] || translations['en'][key];
    } catch (error) {
        console.log('Çeviri hatası:', error);
        return translations['en'][key];
    }
}

// Sayfa yüklendiğinde
document.addEventListener('DOMContentLoaded', function() {
    // i18n mesajlarını yükle
    loadI18nMessages();
    
    // Kaydedilmiş dil tercihini yükle
    chrome.storage.sync.get('preferredLanguage', function(data) {
        const currentLang = data.preferredLanguage || navigator.language.split('-')[0];
        
        // HTML lang özelliğini güncelle
        document.documentElement.lang = currentLang;
        
        // Dil seçiciyi güncelle
        const languageSelector = document.getElementById('languageSelector');
        if (languageSelector) {
            languageSelector.value = currentLang;
        }
        
        // Popup dilini güncelle
        updatePopupLanguage(currentLang);
    });

    // Dil seçici değiştiğinde
    const languageSelector = document.getElementById('languageSelector');
    if (languageSelector) {
        languageSelector.addEventListener('change', function() {
            changeLanguage(this.value);
        });
    }

    // Ayarlar butonunu dinle
    const optionsButton = document.getElementById('openOptions');
    if (optionsButton) {
        optionsButton.addEventListener('click', function() {
            if (chrome.runtime.openOptionsPage) {
                chrome.runtime.openOptionsPage();
            } else {
                window.open(chrome.runtime.getURL('options.html'));
            }
        });
    }

    // Numaraları göster/gizle butonunu dinle
    const toggleButton = document.getElementById('toggleNumbers');
    if (toggleButton) {
        toggleButton.addEventListener('click', function() {
            chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                if (tabs[0] && tabs[0].url && tabs[0].url.includes('google.')) {
                    try {
                        // Önce content script'i yükle
                        chrome.scripting.executeScript({
                            target: { tabId: tabs[0].id },
                            files: ['content.js']
                        }).then(() => {
                            // Sonra mesaj gönder
                            chrome.tabs.sendMessage(tabs[0].id, {
                                action: "toggleNumbers"
                            }).catch(err => console.log('Mesaj gönderme hatası:', err));
                        }).catch(err => console.log('Script yükleme hatası:', err));
                    } catch (error) {
                        console.log('Tab işleme hatası:', error);
                    }
                }
            });
        });
    }
}); 