// Eklenti yüklendiğinde çalışacak fonksiyon
chrome.runtime.onInstalled.addListener(() => {
  // Varsayılan ayarları kaydet
  chrome.storage.sync.set({
    highlightDomains: [],
    fontSize: 35,
    defaultColor: '#838383',
    highlightColor: '#FF0000',
    preferredLanguage: 'tr'
  });
});

// Content script'ten gelen mesajları dinle
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "openOptions") {
    chrome.runtime.openOptionsPage();
  }
  return true;
});

// Tab güncellendiğinde content script'i yeniden yükle
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('google.')) {
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['content.js']
    }).catch(err => console.log('Content script yükleme hatası:', err));
  }
});

// Aktif tab değiştiğinde content script'i kontrol et
chrome.tabs.onActivated.addListener((activeInfo) => {
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if (tab.url && tab.url.includes('google.')) {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      }).catch(err => console.log('Content script yükleme hatası:', err));
    }
  });
});