// Global değişkenler
let globalIndex = 1;
let highlightDomains = [];
let fontSize = 35;
let defaultColor = '#838383';
let highlightColor = '#FF0000';
let currentLanguage = 'tr';
let numbersVisible = true;

// Dil çevirileri
const translations = {
    'tr': {
        'optionsLinkText': 'Ayarlar'
    },
    'en': {
        'optionsLinkText': 'Options'
    },
    'de': {
        'optionsLinkText': 'Einstellungen'
    },
    'fr': {
        'optionsLinkText': 'Paramètres'
    },
    'es': {
        'optionsLinkText': 'Opciones'
    }
};

// Belirli bir dil için çeviri al
function getTranslation(key) {
    return translations[currentLanguage]?.[key] || translations['en'][key];
}

// Ayarları yükleme fonksiyonu
function loadOptions() {
    return new Promise((resolve) => {
        chrome.storage.sync.get({
            highlightDomains: [],
            fontSize: 35,
            defaultColor: '#838383',
            highlightColor: '#FF0000',
            preferredLanguage: 'tr'
        }, function(items) {
            highlightDomains = items.highlightDomains;
            fontSize = items.fontSize;
            defaultColor = items.defaultColor;
            highlightColor = items.highlightColor;
            currentLanguage = items.preferredLanguage;
            resolve();
        });
    });
}

// Numaraları göster/gizle fonksiyonu
function toggleNumbers() {
    numbersVisible = !numbersVisible;
    const numbers = document.querySelectorAll('.result-number');
    numbers.forEach(number => {
        number.style.display = numbersVisible ? 'flex' : 'none';
    });
}

// Mevcut sayfa numarasını alma fonksiyonu
function getCurrentPage() {
    const url = new URL(window.location.href);
    const startParam = url.searchParams.get('start');
    return startParam ? Math.floor(parseInt(startParam) / 10) + 1 : 1;
}

// Arama sonuçlarına numara ekleme fonksiyonu
function addNumbersToResults() {
    // Ana arama sonuçları konteynerini bul
    const mainResults = document.getElementById('rso');
    if (!mainResults) return;

    // Sadece organik arama sonuçlarını seç
    const results = Array.from(mainResults.querySelectorAll('div.g, div[data-hveid]:not([data-content-feature])'))
        .filter(result => {
            // Eğer sonuç bir organik arama sonucu değilse atla
            if (result.closest('.related-question-pair') || // İlgili sorular
                result.closest('[class*="map"]') || // Haritalar
                result.closest('[class*="knowledge"]') || // Bilgi paneli
                result.closest('.g-blk') || // Özel bloklar
                result.closest('.kp-blk') || // Bilgi kartları
                result.closest('.ULSxyf') || // Resim sonuçları
                result.closest('.commercial-unit-desktop-top') || // Reklam birimleri
                result.closest('g-section-with-header') || // Özel başlıklı bölümler
                result.closest('[data-content-feature]')) { // Özel içerik özellikleri
                return false;
            }

            // Ana link yapısını kontrol et
            const mainLink = result.querySelector('a[ping], div[role="heading"] a, h3 a');
            if (!mainLink) return false;

            // Görünürlük kontrolü
            const style = window.getComputedStyle(result);
            if (style.display === 'none' || style.visibility === 'hidden' || style.height === '0px') {
                return false;
            }

            // Sonucun içeriğini kontrol et
            const hasContent = result.textContent.trim().length > 0;
            if (!hasContent) return false;

            return true;
        })
        .filter((result, index, self) => {
            // Yinelenen sonuçları filtrele
            const resultText = result.textContent.trim();
            return index === self.findIndex(r => r.textContent.trim() === resultText);
        });

    let currentPage = getCurrentPage();
    let visibleIndex = (currentPage - 1) * 10 + 1;

    results.forEach(result => {
        // Eğer sonuç zaten numaralandırılmışsa atla
        if (result.querySelector('.result-number')) return;

        // Sonucun pozisyonunu ayarla
        if (!result.style.position || result.style.position === 'static') {
            result.style.position = 'relative';
        }

        addNumberToResult(result, visibleIndex);
        visibleIndex++;
    });
}

// Belirli bir sonuca numara ekleme fonksiyonu
function addNumberToResult(result, index) {
    let numberContainer = document.createElement('div');
    numberContainer.className = 'result-number';
    numberContainer.style.cssText = `
        position: absolute;
        left: -60px;
        top: 0;
        z-index: 1000;
        display: ${numbersVisible ? 'flex' : 'none'};
        align-items: center;
        justify-content: flex-end;
        width: 50px;
    `;

    let hashSpan = document.createElement('span');
    hashSpan.textContent = '#';
    hashSpan.style.cssText = `
        font-size: ${parseInt(fontSize) - 15}px;
        font-weight: bold;
        margin-right: 2px;
    `;

    let numberSpan = document.createElement('span');
    numberSpan.textContent = `${index}`;
    numberSpan.style.cssText = `
        font-size: ${fontSize}px;
        font-weight: bold;
    `;

    let link = result.querySelector('a[ping], div[role="heading"] a, h3 a');
    let color = defaultColor;

    if (link) {
        let domain;
        try {
            const url = new URL(link.href);
            domain = url.hostname.replace(/^www\./, '');
        } catch (error) {
            domain = '';
        }

        if (domain && highlightDomains.some(d => {
            let cleanD = d.replace(/^(https?:\/\/)?(www\.)?/, '');
            return domain === cleanD || domain.endsWith('.' + cleanD);
        })) {
            color = highlightColor;
        }
    }

    hashSpan.style.color = color;
    numberSpan.style.color = color;

    numberContainer.appendChild(hashSpan);
    numberContainer.appendChild(numberSpan);
    result.insertBefore(numberContainer, result.firstChild);
}

// Result-stats içeriğini gösterme ve ayarlar bağlantısını ekleme fonksiyonu
function showResultStats() {
    const resultStats = document.getElementById('result-stats');
    const searchDiv = document.getElementById('topstuff');

    if (resultStats && searchDiv && !document.getElementById('result-stats-display')) {
        const newDiv = document.createElement('div');
        newDiv.id = 'result-stats-display';

        // İçerik ve yeni bağlantı için konteyner oluştur
        const contentWrapper = document.createElement('div');
        contentWrapper.style.display = 'flex';
        contentWrapper.style.justifyContent = 'space-between';
        contentWrapper.style.alignItems = 'center';

        // Result-stats içeriğini ekle
        const statsContent = document.createElement('span');
        statsContent.innerHTML = resultStats.innerHTML;
        contentWrapper.appendChild(statsContent);

        // Ayarlar bağlantısını oluştur
        const optionsLink = document.createElement('a');
        optionsLink.textContent = getTranslation('optionsLinkText');
        optionsLink.href = '#';
        optionsLink.style.marginLeft = 'auto';
        optionsLink.addEventListener('click', (e) => {
            e.preventDefault();
            chrome.runtime.sendMessage({action: "openOptions"});
        });
        contentWrapper.appendChild(optionsLink);

        newDiv.appendChild(contentWrapper);

        newDiv.style.cssText = `
            padding: 10px;
            background-color: #f8f9fa;
            border: 1px solid #dfe1e5;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
            color: #000000;
        `;

        searchDiv.parentNode.insertBefore(newDiv, searchDiv);
    }
}

// Sayfa değiştiğinde global indeksi sıfırlama fonksiyonu
function resetGlobalIndex() {
    const currentPage = getCurrentPage();
    globalIndex = (currentPage - 1) * 10 + 1;
}

// Sayfa yüklendiğinde ve değişiklik olduğunda çalışan ana fonksiyon
async function main() {
    await loadOptions();
    resetGlobalIndex();
    addNumbersToResults();
    showResultStats();
}

// Sayfa yüklendiğinde ana fonksiyonu çalıştır
window.addEventListener('load', main);

// DOM değişikliklerini izlemek için observer
const observer = new MutationObserver((mutations) => {
    for (let mutation of mutations) {
        if (mutation.type === 'childList') {
            main();
            break;
        }
    }
});

// Observer'ı başlat
observer.observe(document.body, {
    childList: true,
    subtree: true
});

// Mesaj dinleyici
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "toggleNumbers") {
        toggleNumbers();
    } else if (request.action === "changeLanguage") {
        currentLanguage = request.lang;
        main();
    }
    sendResponse({success: true});
    return true;
});